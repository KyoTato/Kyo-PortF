const yearEls = document.querySelectorAll('#year, #footerYear');
const currentYear = new Date().getFullYear();
yearEls.forEach(el => {
  el.textContent = currentYear;
});

const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    mainNav.classList.toggle('open');
  });
}

const scrollTriggers = document.querySelectorAll('[data-scroll-target]');
scrollTriggers.forEach(button => {
  button.addEventListener('click', () => {
    const target = document.querySelector(button.dataset.scrollTarget);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    if (mainNav) {
      mainNav.classList.remove('open');
    }

    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    const navMatch = [...document.querySelectorAll('.nav-link')].find(link =>
      link.dataset.scrollTarget === button.dataset.scrollTarget
    );

    if (navMatch) {
      navMatch.classList.add('active');
    }
  });
});

const form = document.querySelector('.contact-form');
if (form) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    alert('This demo form is ready to connect to an email service.');
  });
}
